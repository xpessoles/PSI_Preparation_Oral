##Bibliothèques
from py2duino import*
import math
import time
import matplotlib.pyplot as plt

##Communication avec l'arduino
#Déclaration de l'arduino et de ses ports
ar1=Arduino(4)
#Entrées
ar1.pinMode(0,"INPUT") #Pesée brute
ar1.pinMode(1,"INPUT") #Pesée filtrée
ar1.pinMode(4,"INPUT") #Bouton d'arrêt de la pompe
#Sorties (sens et pwm) pour le hacheur de la pompe
ar1.pinMode(5,"OUTPUT")
ar1.pinMode(6,"OUTPUT")
#Declaration du hacheur du moteur de la pompe
pompe=DCmotor(ar1,1,5,6,1)
#Déclaration du sélecteur
marche=DigitalInput(ar1,4)
#Déclaration des signaux de pesée
val_pes_brute=AnalogInput(ar1,0)
val_pes_filtre=AnalogInput(ar1,1)

##Fonctions pour les pesées
def pesee_brute():
    return(val_pes_brute.read()*500/(1024*1.67/5))
def pesee_filtre():
    return(val_pes_filtre.read()*500/(1024*1.67/5))   

    
##Periode d'échantillonnage et durée de l'essai
#Période d'échantillonnage
Te = 0.05
# Temps de mesure souhaité
tempsmax = 1200
#Calcul du nombre de points nécessaire
nbpt = int(tempsmax/Te)
##Définition de la sollicitation sinusoîdale de la pompe en sinus, pulsation omega en rad/s
omega1=10
omega2=0.07
##Initialisations diverses
demande_arret=0
tps=[]
vol_brut=[]
vol_filtre=[]

##Programme principal
print("Attente début prélèvement")
for i in range(nbpt):
    if marche.read()==0:
        if demande_arret==0:
            tac=time.clock()
            pompe.write(0)
            tps.append(i*Te)
            vol_brut.append(pesee_brute())
            vol_filtre.append(pesee_filtre())
            tic=time.clock()
            time.sleep(Te-(tic-tac))
        elif demande_arret==1:
            print("Fin de prélèvement")
            break
    elif marche.read()==1:
        demande_arret=1
        tac=time.clock()
        pompe.write(215+40*math.sin(i*Te*(omega1+0.1*omega1*math.cos(omega2*i*Te))))
        tps.append(i*Te)
        vol_brut.append(pesee_brute())
        vol_filtre.append(pesee_filtre())
        tic=time.clock()
        time.sleep(Te-(tic-tac))
##Fin du programme
pompe.write(0)
ar1.close()
#Tracé des courbes
plt.figure()
plt.xlabel('temps en s')
plt.ylabel('volumes en mL')
plt.plot(tps,vol_brut,linewidth=1,color='red',label="Signal S1 pesée brute")
plt.plot(tps,vol_filtre,linewidth=1,color='blue',label="Signal S2 pesée filtrée")
plt.legend()
plt.show()



    

