##BIBLIOTHEQUES
from py2duino import*
import math
import time
import matplotlib.pyplot as plt
from scipy.stats import linregress
import numpy as np
##Communication avec l'hemomixer
#Déclaration du port série
ser = serial.Serial()
ser.baudrate = 9600
ser.port = 'COM1'
ser.bytesize = serial.EIGHTBITS #number of bits per bytes
ser.parity = serial.PARITY_NONE #set parity check: no parity
ser.stopbits = serial.STOPBITS_ONE #number of stop bits
ser.open()
#Définition des procedures utiles
def usine():
    ser.write(b'AT00=07\r\n')
    time.sleep(2*Te)
def sortie_usine():
    ser.write(b'AT00=08\r\n')
    time.sleep(2*Te)
def clamp_bas():
    ser.write(b'AT07=01\r\n')
    time.sleep(2*Te)
def clamp_milieu():
    ser.write(b'AT07=32\r\n')
    time.sleep(2*Te)
def clamp_haut():
    ser.write(b'AT07=02\r\n')
    time.sleep(2*Te)
def marche_agitation():
    ser.write(b'AT07=33\r\n')
    time.sleep(0.65*Te)
def arret_agitation():
    ser.write(b'AT07=09\r\n')
    time.sleep(0.65*Te)
def marche_jauge():
    ser.write(b'AT09=01\r\n')
    time.sleep(1)
def arret_jauge():
    ser.write(b'AT09=00\r\n')
    time.sleep(2*Te)
def au():
    print("Arrêt suite erreur")
    print("Fin de l'agitation")
    arret_agitation()
    time.sleep(6)
    print("Reinitialisation")
    clamp_bas()
    pompe.write(0)
    arret_jauge()
    time.sleep(1)
    sortie_usine()
    ar1.close()
    ser.close()
    print("système prêt pour un nouveau départ")
##Communication avec l'arduino
#Déclaration de l'arduino et de ses ports
ar1=Arduino(4)
#Entrées
ar1.pinMode(0,"INPUT") #Pesée brute
ar1.pinMode(1,"INPUT") #Pesée filtrée
ar1.pinMode(4,"INPUT") #Bouton d'arrêt de la pompe
#Sorties (sens et pwm) pour le hacheur de la pompe
ar1.pinMode(5,"OUTPUT")
ar1.pinMode(6,"OUTPUT")
#Declaration du hacheur du moteur de la pompe
pompe=DCmotor(ar1,1,5,6,1)
#Déclaration du sélecteur
marche=DigitalInput(ar1,4)
#Déclaration des signaux de pesée
val_pes_filtre=AnalogInput(ar1,1)

##Fonction pour la pesée filtrée
def pesee_filtre():
    return(val_pes_filtre.read()*500/(1024*1.67/5)-tare)

##Fonction incrémentations des listes
def empiler(tps,vol,vol_lin,phase,Te,i,val1,val2,val3):
    tps.append(i*Te)
    vol.append(val1)
    vol_lin.append(val2)
    phase.append(val3)
##Fonction linearisation à partir de la bibliothèque Scipy
def linearisation(T,S2,dt,Te):
    N=int(dt/Te)
    regression=linregress(T[-1-N:-1],S2[-1-N:-1])
    return([regression[0]*T[-1]+regression[1],regression[0]])
#Fonction empiler de la phase 1
def empiler1():
    empiler(tps,vol,vol_lin,phase,Te,i,pesee_filtre(),pesee_filtre(),1)
#Fonction empiler de la phase 2
def empiler2():
    empiler(tps,vol,vol_lin,phase,Te,i,pesee_filtre(),pesee_filtre(),2)
#Fonction empiler de la phase 5
def empiler5():
    empiler(tps,vol,vol_lin,phase,Te,i,pesee_filtre(),linearisation(tps,vol,9,Te)[0],5)
##Fonctions à écrire à l'activité 11
#Fonction empiler de la phase 3
def empiler3():
    empiler(tps,vol,vol_lin,phase,Te,i,pesee_filtre(),linearisation(tps,vol,(i*Te),Te)[0],3)

#Fonction empiler de la phase 4
def empiler4():
    empiler(tps,vol,vol_lin,phase,Te,i,pesee_filtre(),linearisation(tps,vol,30,Te)[0],4)

##Periode d'échantillonnage et paramètres de l'essai
#Période d'échantillonnage
Te = 0.11
# Temps de mesure souhaité
tempsmax = 120
#Calcul du nombre de points nécessaires
nbpt = int(tempsmax/Te)
#Définition du vecteur des temps complet
temps=np.linspace(0,tempsmax,nbpt)
#Volume à prélever souhaité en ml
vol_souhaite=100
#Définition de la sollicitation sinusoîdale de la pompe en sinus, pulsation omega en rad/s
omega1=10
omega2=0.07

##Programme principal

##Phase d'initialisation
#Mise en fonctionnement hémomixer
usine()
marche_jauge()
clamp_milieu()
tare=0
#Tare de la pesée
tare=pesee_filtre()
print("la valeur de la tare est :",tare)
tps=[]
vol=[]
vol_lin=[]
phase=[]
tempsinitial=time.clock()
i=0
secu=marche.read()
#Initialisation des étapes de chaque phase (0 début, 1 en cours, 2 fin)
etape1=0
etape2=0
etape3=0
etape4=0
etape5=0

###Boucle à chaque période d'échantillonnage
while(secu==1):
#Instant de début de la période d'échantillonnage en cours
    tac=time.clock()

##Attente des 5 premiers mL avant le début de l'agitation - PHASE 1
    if (etape1<2):
        #Actions au début de l'étape
        if (etape1==0):
            print("Phase 1 : attente d'un volume de 5 mL pour lancer l'agitation")
            etape1=1
            empiler1()
        else:
            if (pesee_filtre()<5):
                empiler1()
            else:
                empiler1()
                etape1=2
       
##Agitation sans regression linéaire - PHASE 2
    if (etape1==2 and etape2<2):
        #Actions au début de la phase
        if (etape2==0):
            print("Phase 2 : agitation sans regression linéaire")
            #Mise en marche de l'agitation
            marche_agitation()
            empiler2()
            etape2=1
            debut2=time.clock()
        else:
            if((time.clock()-debut2)<5):
                empiler2()
            else:
                empiler2()
                etape2=2

##Agitation avec regression linéaire augmentant de 5 s à 30 s - PHASE 3
    if (etape2==2 and etape3<2):
        #Actions au début de la phase
        if (etape3==0):
            print("Phase 3 : regression linéaire entre 5 et 30 secondes")
            empiler3()
            etape3=1
            debut3=time.clock()
        else:
            if((time.clock()-debut3)<25):
                empiler3()
            else:
                empiler3()
                etape3=2

##Agitation avec regression linéaire sur 30 s fixes - PHASE 4
    if (etape3==2 and etape4<2):
        #Actions au début de la phase
        if (etape4==0):
            print("regression linéaire sur 30 secondes fixe")
            condition=False
            empiler4()
            vol_restant=vol_souhaite-vol_lin[-1]
            #Condition à écrire dans le if()
            if ((vol_restant/linearisation(tps,vol,30,Te)[1])<15):
                condition=True
            etape4=1
        #Activités pendant la phase
        else:
            if (condition==False):
                empiler4()
                vol_restant=vol_souhaite-vol_lin[-1]
                #Condition à écrire à nouveau (idem ligne 206)
                if ((vol_restant/linearisation(tps,vol,30,Te)[1])<15):
                    condition=True
        #Actions à la fin de la phase
            else:
                empiler4()
                etape4=2

##Fin du prelèvement avec arrêt de l'agitation - PHASE 5
    if (etape4==2 and etape5<2):
        #Actions au début de la phase
        if (etape5==0):
            print("Phase 5 : demande d'arrêt de l'agitation et fin du prélèvement")
            arret_agitation()
            empiler5()
            etape5=1
            debut5=time.clock()
        #Activités pendant la phase : regression linéaire sur 9 secondes seulement avant le clampage final
        else:
            if (vol_lin[-1]<=vol_souhaite):
                empiler5()
            else:
                break
    #La pompe est toujours en marche pendant toutes les étapes (on fait varier la pulsation de la pompe)
    pompe.write(215+40*math.sin(i*Te*(omega1+0.1*omega1*math.cos(omega2*i*Te))))
    secu=marche.read()
    #Attente de la fin de la période d'échantillonnage
    tic=time.clock()
    time.sleep(Te-(tic-tac))
    i=i+1
##Arret des mesures et fin prelevement
if (secu==1):
    print("la pesée vaut alors :",pesee_filtre())
    clamp_bas()
    pompe.write(0)
    arret_jauge()
    time.sleep(1)
    sortie_usine()
    print("durée du prélèvement : ",time.clock()-tempsinitial)
else:
    print("Arrêt suite erreur")
    print("Fin de l'agitation")
    arret_agitation()
    time.sleep(6)
    print("reinitialisation")
    clamp_bas()
    pompe.write(0)
    arret_jauge()
    time.sleep(1)
    sortie_usine()
    print("système prêt pour un nouveau depart")
##Arrêt des liaisons séries
ar1.close()
ser.close()
##Tracé des courbes
if (secu==1):
    plt.figure(1)
    plt.xlabel('temps en seconde')
    plt.ylabel('volumes prélevés et estimés')
    plt.plot(tps,vol,linewidth=1,color='red',label='Signal S2')
    plt.plot(tps,vol_lin,linewidth=1,color='blue',label='Signal S3')
    plt.legend()
    plt.figure(2)
    plt.xlabel('temps en seconde')
    plt.ylabel('numéro de la phase active')
    plt.plot(tps,phase)
    plt.show()

