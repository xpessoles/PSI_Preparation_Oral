# -*- coding: utf-8 -*-

from pylab import *
from scipy.linalg import solve

#### Lecture des données dans le fichier ####
data2  = fromfile('C:/Users/Alexis/mesure.hmxacq')
data2 = data2[208:].reshape((-1,7))
S2=data2[:,1]*1050/3.48*1.0605        ## vecteur des mesures de S2

##Définition de Te et dt et initialisation de tps, vol et vol_lin
Te=0.01
dt=30
tps=[]
vol=[]
vol_lin=[]

##Fonction à programmer
def linearisation(T,S2,dt,Te):
    N=int(dt/Te)
    temps=array(T[-1-N:-1])
    signal=array(S2[-1-N:-1])
    P=[[sum(temps**2),sum(temps)],[sum(temps),N]]
    Q=[sum(signal*temps),sum(signal)]
    X=solve(P,Q)
    return(X[0]*T[-1]+X[1])

##Initialisation entre 0 et 30 secondes sans linéarisation
for k in range (int(30/Te)):
    tps.append(k*Te)
    vol.append(S2[k])
    vol_lin.append(S2[k])
        
##Linéarisation glissante à partir de 30 secondes
for k in range (int(30/Te),len(S2)):
    tps.append(k*Te)
    vol.append(S2[k])
    vol_lin.append(linearisation(tps,vol,dt,Te))
    
#### Programmation du tracé des courbes obtenues
plt.figure()
plt.xlabel('temps en s')
plt.ylabel('volumes en mL')
#Intégrer ici les tracés de vol (en rouge) et vol_lin (en bleu)
plt.plot(tps,vol,linewidth=1,color='red')
plt.plot(tps,vol_lin,linewidth=1,color='blue')
#Tracé de la figure
plt.show()

