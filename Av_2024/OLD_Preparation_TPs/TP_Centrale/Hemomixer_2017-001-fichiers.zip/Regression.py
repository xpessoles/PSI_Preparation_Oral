# -*- coding: utf-8 -*-

from pylab import *
from scipy.linalg import solve

#### Lecture des données dans le fichier ####
data2  = fromfile('C:/Users/Alexis/mesure.hmxacq')
data2 = data2[208:].reshape((-1,7))
S2=data2[:,1]*1050/3.48*1.0605        ## vecteur des mesures de S2

##Définition de Te et dt et initialisation de tps, vol et vol_lin
Te=0.01
dt=30
tps=[]
vol=[]
vol_lin=[]

##Fonction à programmer
def linearisation(T,S2,dt,Te):


##Initialisation entre 0 et 30 secondes sans linéarisation
for k in range (int(30/Te)):
    tps.append(k*Te)
    vol.append(S2[k])
    vol_lin.append(S2[k])
        
##Linéarisation glissante à partir de 30 secondes
for k in range (int(30/Te),len(S2)):
    tps.append(k*Te)
    vol.append(S2[k])
    vol_lin.append(linearisation(tps,vol,dt,Te))
    
#### Programmation du tracé des courbes obtenues
plt.figure()



#Intégrer ici les tracés de vol (en rouge) et vol_lin (en bleu)



#Tracé de la figure
plt.show()

