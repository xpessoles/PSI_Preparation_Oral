clear all
close all

Kr=30*1e3%Raideur du ressort
Kcorde=3000%Raideur de la corde
Km=0.025%Constante de couple
Ke=Km%Constante de fem
r=0.0188%rapport de reduction du reducteur
Rp=0.01%Rayon de la poulie
J=0.05%Inertie ramenee a l'arbre moteur
R=1.1%Resistance du moteur
Kc=1;%
Kh=1;%Gain du hacheur
Ka=Kc;%Gain d'adaptation



